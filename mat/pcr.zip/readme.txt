-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
Source Code for the paper: 
Y. Lou, Y. He, L. Wang, and G. Chen, "Predicting Network Controllability Robustness: A Convolutional Neural Network Approach", arXiv:1908.09471 (preprint 2019) & IEEE Transactions on Cybernetics (under review 2020)
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 

-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
updated: 20 May 2020
programmer: Y. He (yaodonghe2-c@my.cityu.edu.hk) and Y. Lou (felix.lou@my.cityu.edu.hk)
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 

-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
[abbreviation]:
CNN - convolutional neural network
CR  - controllability robustness
AM  - adjacency matrix
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 

-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
[files]:
'ctrl_robust_train.py'	= to train a CNN with given training samples (AM + CR curve)
'ctrl_robust_test.py'	= to predict the CR curve with a given input AM
'atk_simulation_eg.py'  = for run time comparison, to demonstrate that attack simulations are time-consuming
'embedding_matrix.txt'  = embedding matrix for CNN training
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 

-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 
[data]:
The training samples (AMs + CR curves, 908MB) and the trained CNN models (4.79 GB) are available upon request by emailing to Y.Lou (felix.lou@my.cityu.edu.hk).

More network topologies and attack strategies are available in: https://fylou.github.io/sourcecode.html
-----  -----  -----  -----  -----  -----  -----  -----  -----  ----- 

