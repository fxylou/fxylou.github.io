from time import time

from torch.utils.data import DataLoader

from parameters import test_params
from utils import *


def predict_multi(data_loader, device, model):
    model.eval()
    sim_pt, sim_yc, sim_lc, sim_cc = [], [], [], []
    pred_pt, pred_yc, pred_lc, pred_cc = [], [], [], []
    tic = time()
    for batched_graph, labels_pt, labels_yc, labels_lc, labels_cc in data_loader:
        batched_graph = batched_graph.to(device)
        labels_pt = labels_pt.to(device)
        labels_yc = labels_yc.to(device)
        labels_lc = labels_lc.to(device)
        labels_cc = labels_cc.to(device)
        logits_pt, logits_yc, logits_lc, logits_cc = model(batched_graph)
        temp_logits_pt = logits_pt.cpu().detach().numpy()
        temp_logits_yc = logits_yc.cpu().detach().numpy()
        temp_logits_lc = logits_lc.cpu().detach().numpy()
        temp_logits_cc = logits_cc.cpu().detach().numpy()
        temp_labels_pt = labels_pt.cpu().detach().numpy()
        temp_labels_yc = labels_yc.cpu().detach().numpy()
        temp_labels_lc = labels_lc.cpu().detach().numpy()
        temp_labels_cc = labels_cc.cpu().detach().numpy()
        if len(pred_pt) == 0:
            sim_pt = temp_labels_pt
            sim_yc = temp_labels_yc
            sim_lc = temp_labels_lc
            sim_cc = temp_labels_cc
            pred_pt = temp_logits_pt
            pred_yc = temp_logits_yc
            pred_lc = temp_logits_lc
            pred_cc = temp_logits_cc
        else:
            sim_pt = np.concatenate((sim_pt, temp_labels_pt))
            sim_yc = np.concatenate((sim_yc, temp_labels_yc))
            sim_lc = np.concatenate((sim_lc, temp_labels_lc))
            sim_cc = np.concatenate((sim_cc, temp_labels_cc))
            pred_pt = np.concatenate((pred_pt, temp_logits_pt))
            pred_yc = np.concatenate((pred_yc, temp_logits_yc))
            pred_lc = np.concatenate((pred_lc, temp_logits_lc))
            pred_cc = np.concatenate((pred_cc, temp_logits_cc))
    toc = time() - tic
    pred_pt = np.round(np.array(pred_pt).squeeze(), 3) * 100
    pred_yc = np.array(pred_yc).squeeze()
    pred_lc = np.array(pred_lc).squeeze()
    pred_cc = np.round(np.array(pred_cc).squeeze(), 3) * 100
    sim_pt = np.round(np.array(sim_pt).squeeze(), 3) * 100
    sim_yc = np.array(sim_yc).squeeze()
    sim_lc = np.array(sim_lc).squeeze()
    sim_cc = np.round(np.array(sim_cc).squeeze(), 3) * 100
    mae_yc = np.mean(np.abs(sim_yc - pred_yc), axis=1)
    mae_lc = np.mean(np.abs(sim_lc - pred_lc), axis=1)

    peak_acc1, peak_acc2 = [], []
    for std in np.arange(0, 5, 0.5):
        peak_acc1.append(np.sum(np.abs(sim_pt - pred_pt) <= std) / len(pred_pt))
        peak_acc2.append(np.sum(np.abs(sim_cc - pred_cc) <= std) / len(pred_cc))
    prediction = {
        'sim_yc':     sim_yc,
        'sim_lc':     sim_lc,
        'sim_t':      sim_pt,
        'sim_m':      sim_cc,
        'pred_yc':    pred_yc,
        'pred_lc':    pred_lc,
        'pred_t':     pred_pt,
        'pred_m':     pred_cc,
        'mae_yc':     mae_yc,
        'mae_lc':     mae_lc,
        'accuracy_t': peak_acc1,
        'accuracy_m': peak_acc2,
        'time':       toc / 900
    }
    return prediction


def predict(data_loader, device, model):
    model.eval()
    sim = []
    pred = []
    tic = time()
    for batched_graph, labels in data_loader:
        batched_graph = batched_graph.to(device)
        labels = labels.to(device)
        logits = model(batched_graph)
        temp_logits = logits.cpu().detach().numpy()
        temp_labels = labels.cpu().detach().numpy()
        if len(pred) == 0:
            sim = temp_labels
            pred = temp_logits
        else:
            sim = np.concatenate((sim, temp_labels))
            pred = np.concatenate((pred, temp_logits))
    toc = time() - tic
    pred = np.array(pred).squeeze()
    sim = np.array(sim).squeeze()
    if test_params['label'] == 'pt':
        return calculate_peak_accuracy(pred, sim, toc / 900)
    elif test_params['label'] == 'cc':
        return calculate_maximum_accuracy(pred, sim, toc / 900)
    else:
        mae = np.mean(np.abs(sim - pred), axis=1)
    if test_params['label'] == 'yc':
        prediction = {
            'sim_yc':  sim,
            'pred_yc': pred,
            'time':    toc / 900,
            'mae_yc':  mae
        }
    if test_params['label'] == 'lc':
        prediction = {
            'sim_lc':  sim,
            'pred_lc': pred,
            'time':    toc / 900,
            'mae_lc':  mae
        }
    return prediction


def calculate_maximum_accuracy(pred, sim, time, max_std=5):
    prediction = {
        'pred_m': np.round(pred, 3) * 100,
        'sim_m':  np.round(sim, 3) * 100,
        'time':   time
    }
    peak_acc = []
    for std in np.arange(0, max_std, 0.5):
        peak_acc.append(np.sum(np.abs(prediction['sim_m'] - prediction['pred_m']) <= std) / len(prediction['sim_m']))
    prediction['accuracy_m'] = peak_acc
    return prediction


def calculate_peak_accuracy(pred, sim, time, max_std=5):
    prediction = {
        'pred_t': np.round(pred, 3) * 100,
        'sim_t':  np.round(sim, 3) * 100,
        'time':   time
    }
    peak_acc = []
    for std in np.arange(0, max_std, 0.5):
        peak_acc.append(np.sum(np.abs(prediction['sim_t'] - prediction['pred_t']) <= std) / len(prediction['sim_t']))
    prediction['accuracy_t'] = peak_acc
    return prediction


if __name__ == '__main__':
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    graphs = load_network(f'./data/test/testing_networks_{test_params["atk"]}_isd{test_params["isd"]}',
        test_params['label'])
    model_path = f'./checkpoints/{test_params["atk"]}_isd{test_params["isd"]}_{test_params["label"]}'
    model = torch.load(model_path).to(device)
    if test_params["label"] == 'all':
        test_loader = DataLoader(
            graphs,
            batch_size=512,
            collate_fn=collate_multi,
        )
        prediction = predict_multi(test_loader, device, model)
    else:
        test_loader = DataLoader(
            graphs,
            batch_size=512,
            collate_fn=collate,
        )
        prediction = predict(test_loader, device, model)

    file_path = f'./prediction/{test_params["atk"]}_isd{test_params["isd"]}_{test_params["label"]}'
    sio.savemat(file_path + '.mat', prediction)
    # np.save(file_path, prediction)
    if test_params['label'] in ['all', 'pt']:
        print(prediction['accuracy_t'])
    print()
    if test_params['label'] in ['all', 'cc']:
        print(prediction['accuracy_m'])
    print()
    if test_params['label'] in ['all', 'yc']:
        for i in range(0, 900, 100):
            print(np.mean(prediction['mae_yc'][i:i + 100]), end=',')
    print()
    if test_params['label'] in ['all', 'lc']:
        for i in range(0, 900, 100):
            print(np.mean(prediction['mae_lc'][i:i + 100]), end=',')
