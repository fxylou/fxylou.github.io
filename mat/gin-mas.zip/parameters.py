train_params = {
    'max_epoch': 300,
    'batch_size': 64,
    'atk': 'ndeg',
    'isd': 0,
    'label': 'all',
}

test_params = {
    'atk': 'ndeg',
    'isd': 1,
    'label': 'all',
}
