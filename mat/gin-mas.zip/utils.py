import dgl
import numpy as np
import scipy.io as sio
import torch


def load_network(path, robustness):
    mat = sio.loadmat(path)
    len_net = len(mat['res'])
    len_instance = len(mat['res'][0])
    networks = mat['res']
    graphs = []
    for i in range(len_net):
        for j in range(len_instance):
            print(
                '\r',
                f'loading {i * len_instance + j + 1} / {len_net * len_instance}  network...',
                end='',
                flush=True
            )
            adj = networks[i, j]['adj'][0][0]
            # g = nx.from_numpy_matrix(adj)
            g = dgl.from_scipy(adj)
            if robustness == 'lc':
                label = networks[i, j]['lc'][0][0]
            if robustness == 'yc':
                label = networks[i, j]['yc'][0][0]
            if robustness == 'pt':
                pt = networks[i, j]['pt'][0][0].squeeze()
                peak = (np.mean(np.where(pt == np.amax(pt))) / adj.shape[0])
                label = peak
            if robustness == 'cc':
                pt = networks[i, j]['pt'][0][0].squeeze()
                cc_peak = np.amax(pt)
                label = cc_peak
            if robustness == 'all':
                label_lc = networks[i, j]['lc'][0][0]
                label_yc = networks[i, j]['yc'][0][0]
                pt = networks[i, j]['pt'][0][0].squeeze()
                peak = (np.mean(np.where(pt == np.amax(pt))) / adj.shape[0])
                cc_peak = np.amax(pt)
                label_pt = peak
                label_cc = cc_peak / adj.shape[0]
            if robustness == 'all':
                graphs.append(
                    {'g': g, 'label_lc': label_lc, 'label_yc': label_yc, 'label_pt': label_pt, 'label_cc': label_cc})
            else:
                graphs.append({'g': g, 'label': label})
    print()
    return graphs


def collate(samples):
    batch_size = len(samples)
    batch_graphs = [sample['g'] for sample in samples]
    batch_labels = [sample['label'] for sample in samples]
    loop_graphs = [dgl.add_self_loop(graph) for graph in batch_graphs]
    return dgl.batch(loop_graphs), torch.tensor(np.array(batch_labels, dtype=np.float32)).squeeze().float().view(
        batch_size, -1)


def collate_multi(samples):
    batch_size = len(samples)
    batch_graphs = [sample['g'] for sample in samples]
    batch_labels_pt = [sample['label_pt'] for sample in samples]
    batch_labels_yc = [sample['label_yc'] for sample in samples]
    batch_labels_lc = [sample['label_lc'] for sample in samples]
    batch_labels_cc = [sample['label_cc'] for sample in samples]
    loop_graphs = [dgl.add_self_loop(graph) for graph in batch_graphs]
    return dgl.batch(loop_graphs), torch.tensor(np.array(batch_labels_pt, dtype=np.float32)).squeeze().float().view(
        batch_size, -1), torch.tensor(np.array(batch_labels_yc, dtype=np.float32)).squeeze().float().view(
        batch_size, -1), torch.tensor(np.array(batch_labels_lc, dtype=np.float32)).squeeze().float().view(
        batch_size, -1), torch.tensor(np.array(batch_labels_cc, dtype=np.float32)).squeeze().float().view(
        batch_size, -1)


def print_progress(now, total, length=40, prefix='progress:'):
    print('\r' + prefix + ' %.2f%%\t' % (now / total * 100), end='')
    print('[' + '>' * int(now / total * length) + '-' * int(length - now / total * length) + ']', end='')


def calculate_param_number(model):
    Total_params = 0
    Trainable_params = 0
    NonTrainable_params = 0

    for param in model.parameters():
        mulValue = np.prod(param.size())
        Total_params += mulValue
        if param.requires_grad:
            Trainable_params += mulValue
        else:
            NonTrainable_params += mulValue

    print(f'Total params: {Total_params}')
    print(f'Trainable params: {Trainable_params}')
    print(f'Non-trainable params: {NonTrainable_params}')
