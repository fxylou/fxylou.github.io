# A Multitask Network Robustness Analysis System Based on the Graph Isomorphism Network

## Dependencies

- networkx
- PyTorch

## Usage

To make it easier for your dataset to be used directly in the code, it is recommended to keep the training data format
the same as in this code. Otherwise, you will need to modify the code in the data-loading part to suit your own dataset.

### Train & Test

```python
python train.py  # Train model
python test.py  # Test model using the prepared trained model
```

### The Prepared Dataset

We prepared a training dataset for your running:
> training_networks_ndeg_isd0.mat

## Cite

This paper will be formally published
in [IEEE Transactions on Cybernetics](https://ieeexplore.ieee.org/xpl/RecentIssue.jsp?punumber=6221036).