import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
from sklearn.utils import shuffle
from torch.utils.data import DataLoader

from model import GIN
from model import Multi_GIN
from parameters import train_params
from utils import *


def evaluate(data_loader, device, model):
    model.eval()
    mse, mae = [], []
    for batched_graph, labels in data_loader:
        batched_graph = batched_graph.to(device)
        labels = labels.to(device)
        logits = model(batched_graph)
        mse.append(mean_squared_error(labels.cpu().detach().numpy(), logits.cpu().detach().numpy()))
        mae.append(mean_absolute_error(labels.cpu().detach().numpy(), logits.cpu().detach().numpy()))
    return np.mean(mse), np.mean(mae)


def evaluate_multi(data_loader, device, model):
    model.eval()
    mse_pt, mae_pt, mse_yc, mse_cc, mae_yc, mse_lc, mae_lc, mae_cc = [], [], [], [], [], [], [], []
    for batched_graph, labels_pt, labels_yc, labels_lc, labels_cc in data_loader:
        batched_graph = batched_graph.to(device)
        labels_pt = labels_pt.to(device)
        labels_yc = labels_yc.to(device)
        labels_lc = labels_lc.to(device)
        labels_cc = labels_cc.to(device)
        logits_pt, logits_yc, logits_lc, logits_cc = model(batched_graph)
        mse_pt.append(mean_squared_error(labels_pt.cpu().detach().numpy(), logits_pt.cpu().detach().numpy()))
        mae_pt.append(mean_absolute_error(labels_pt.cpu().detach().numpy(), logits_pt.cpu().detach().numpy()))

        mse_yc.append(mean_squared_error(labels_yc.cpu().detach().numpy(), logits_yc.cpu().detach().numpy()))
        mae_yc.append(mean_absolute_error(labels_yc.cpu().detach().numpy(), logits_yc.cpu().detach().numpy()))

        mse_lc.append(mean_squared_error(labels_lc.cpu().detach().numpy(), logits_lc.cpu().detach().numpy()))
        mae_lc.append(mean_absolute_error(labels_lc.cpu().detach().numpy(), logits_lc.cpu().detach().numpy()))

        mse_cc.append(mean_squared_error(labels_cc.cpu().detach().numpy(), logits_cc.cpu().detach().numpy()))
        mae_cc.append(mean_absolute_error(labels_cc.cpu().detach().numpy(), logits_cc.cpu().detach().numpy()))
    return np.mean(mse_pt), np.mean(mae_pt), np.mean(mse_yc), np.mean(mae_yc), np.mean(mse_lc), np.mean(
        mae_lc), np.mean(mse_cc), np.mean(mae_cc)


def train_multi(
        device, model,
        data_path=f'./data/train/training_networks_{train_params["atk"]}_isd{train_params["isd"]}.mat',
        robustness=train_params['label'], max_poch=train_params['max_epoch'],
        batch_size=train_params['batch_size']
):
    # data processing
    save_path = f'./checkpoints/{train_params["atk"]}_isd{train_params["isd"]}_{train_params["label"]}'
    graphs = load_network(data_path, robustness)
    graphs = shuffle(graphs)
    train_data_number = round(len(graphs) * 0.9)
    train_loader = DataLoader(
        graphs[:train_data_number],
        batch_size=batch_size,
        collate_fn=collate_multi,
    )
    val_loader = DataLoader(
        graphs[train_data_number:],
        batch_size=256,
        collate_fn=collate_multi,
    )
    # loss function, optimizer and scheduler
    loss_fcn = nn.MSELoss()
    # loss_fcn = peak_loss()
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.5)
    model.to(device)
    # training loop
    all_val_mae_pt, all_val_mae_yc, all_val_mae_lc, all_val_mae_cc = [], [], [], []
    for epoch in range(max_poch):
        model.train()

        L1, L2, L3, L4 = [], [], [], []
        for batch, (batched_graph, labels_pt, labels_yc, labels_lc, labels_cc) in enumerate(train_loader):
            print_progress(batch, train_data_number // batch_size, prefix=f'Epoch {epoch}: ')
            batched_graph = batched_graph.to(device)
            labels_pt = labels_pt.to(device)
            labels_yc = labels_yc.to(device)
            labels_lc = labels_lc.to(device)
            labels_cc = labels_cc.to(device)
            logits_pt, logits_yc, logits_lc, logits_cc = model(batched_graph)
            loss_pt = loss_fcn(logits_pt, labels_pt)
            loss_yc = loss_fcn(logits_yc, labels_yc)
            loss_lc = loss_fcn(logits_lc, labels_lc)
            loss_cc = loss_fcn(logits_cc, labels_cc)
            optimizer.zero_grad()
            L1.append(loss_pt.item())
            L2.append(loss_yc.item())
            L3.append(loss_lc.item())
            L4.append(loss_cc.item())
            w1, w2, w3, w4 = np.var(L1) + 1e-8, np.var(L2) + 1e-8 + 1e-8, np.var(L3) + 1e-8, np.var(L4) + 1e-8
            ws = w1 + w2 + w3 + w4
            w1, w2, w3, w4 = w1 / ws, w2 / ws, w3 / ws, w4 / ws
            # print(w1, w2, w3, w4)
            all_loss = loss_pt / w1 + loss_yc / w2 + loss_lc / w3 + loss_cc / w4
            # print(all_loss)
            all_loss.backward()
            optimizer.step()
        scheduler.step()
        mse_pt, mae_pt, mse_yc, mae_yc, mse_lc, mae_lc, mse_cc, mae_cc = evaluate_multi(train_loader, device, model)
        val_mse_pt, val_mae_pt, val_mse_yc, val_mae_yc, val_mse_lc, val_mae_lc, val_mse_cc, val_mae_cc = evaluate_multi(
            val_loader, device,
            model)
        pre_val_mae_pt = all_val_mae_pt[-1] if len(all_val_mae_pt) > 0 else 'inf'
        pre_val_mae_yc = all_val_mae_yc[-1] if len(all_val_mae_yc) > 0 else 'inf'
        pre_val_mae_lc = all_val_mae_lc[-1] if len(all_val_mae_lc) > 0 else 'inf'
        pre_val_mae_cc = all_val_mae_cc[-1] if len(all_val_mae_cc) > 0 else 'inf'
        all_val_mae_pt.append(val_mae_pt)
        all_val_mae_yc.append(val_mae_yc)
        all_val_mae_lc.append(val_mae_lc)
        all_val_mae_cc.append(val_mae_cc)
        print()
        print(
            f'Epoch {epoch} | mae_pt. {mae_pt:5.3f} | val_mae_pt. {val_mae_pt:5.3f}| mae_yc. {mae_yc:5.3f} | '
            f'val_mae_yc. {val_mae_yc:5.3f} | mae_lc. {mae_lc:5.3f} | val_mae_lc. {val_mae_lc:5.3f}| mae_cc. {mae_cc:5.3f} | val_mae_cc. {val_mae_cc:5.3f}')
        if val_mae_pt <= np.min(all_val_mae_pt) or val_mae_yc <= np.min(all_val_mae_yc) or val_mae_lc <= np.min(
                all_val_mae_lc) or val_mae_cc <= np.min(all_val_mae_cc):
            print(f'val_mae_pt: {pre_val_mae_pt} ---> {val_mae_pt}.')
            print(f'val_mae_yc: {pre_val_mae_yc} ---> {val_mae_yc}.')
            print(f'val_mae_lc: {pre_val_mae_lc} ---> {val_mae_lc}.')
            print(f'val_mae_cc: {pre_val_mae_cc} ---> {val_mae_cc}.')
            print('save model!')
            torch.save(model, save_path)
        if val_mae_pt <= 0.004 and val_mae_yc <= 0.005 and val_mae_lc <= 0.005 and val_mae_cc <= 0.004:
            print(f'Epoch {epoch}, valid mae is small enough, stop training.')
            break


def train(device, model, data_path=f'./data/train/training_networks_{train_params["atk"]}_isd{train_params["isd"]}.mat',
          robustness=train_params['label'], max_poch=train_params['max_epoch'], batch_size=train_params['batch_size']):
    # data processing
    save_path = f'./checkpoints/{train_params["atk"]}_isd{train_params["isd"]}_{train_params["label"]}'
    graphs = load_network(data_path, robustness)
    graphs = shuffle(graphs)
    train_data_number = round(len(graphs) * 0.9)
    train_loader = DataLoader(
        graphs[:train_data_number],
        batch_size=batch_size,
        collate_fn=collate,
    )
    val_loader = DataLoader(
        graphs[train_data_number:],
        batch_size=256,
        collate_fn=collate,
    )
    # loss function, optimizer and scheduler
    loss_fcn = nn.MSELoss()
    # loss_fcn = peak_loss()
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=60, gamma=0.5)
    model.to(device)
    # training loop
    loss_history = []
    all_val_mae = []
    for epoch in range(max_poch):
        model.train()
        total_loss = 0
        for batch, (batched_graph, labels) in enumerate(train_loader):
            print_progress(batch, train_data_number // batch_size, prefix=f'Epoch {epoch}: ')
            batched_graph = batched_graph.to(device)
            labels = labels.to(device)
            logits = model(batched_graph)
            loss = loss_fcn(logits, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        scheduler.step()
        mse, mae = evaluate(train_loader, device, model)
        val_mse, val_mae = evaluate(val_loader, device, model)
        loss_history.append(total_loss / (batch + 1))
        all_val_mae.append(val_mae)
        print()
        print(
            f'Epoch {epoch} | Loss {total_loss / (batch + 1):8.2f} | mse. {mse:8.3f} | val_mse. {val_mse:8.3f}| mae. {mae:8.3f} | '
            f'val_mae. {val_mae:8.7f} ')
        if val_mae <= np.min(all_val_mae):
            print(f'val_mae -> {val_mae}, save model.')
            # save the best model guided by val_mae
            torch.save(model, save_path)
        if val_mae <= 0.005:
            print(f'Epoch {epoch}, valid mae is less than 0.005, stop training.')
            break
    return loss_history


if __name__ == '__main__':
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if train_params['label'] == 'pt':
        output_dim = 1
    else:
        output_dim = 201
    # train model
    if train_params['label'] == 'all':
        model = Multi_GIN(
            input_dim=1,
            hidden_dim=16,
            output_dim=output_dim,
        )
        calculate_param_number(model)
        train_multi(device=device, model=model)
    else:
        model = GIN(
            input_dim=1,
            hidden_dim=16,
            output_dim=output_dim,
        )
        calculate_param_number(model)
        train(device=device, model=model)
